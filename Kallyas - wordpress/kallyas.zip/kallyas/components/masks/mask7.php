<?php if(! defined('ABSPATH')){ return; }?>

<div class="skewmask-block" style="background-color:<?php echo $bgcolor; ?>"></div>